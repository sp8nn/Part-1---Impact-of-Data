﻿using System;
using System.Diagnostics;

Stopwatch stopwatch = Stopwatch.StartNew();

// usage 100 thousand values
int[] largeArr = GenerateRandomArray(100000, 1, 1000);

Console.WriteLine();

MeasureAndPrint("Quick Sort", QuickSort, largeArr);
MeasureAndPrint("Merge Sort", MergeSort, largeArr);

int truncationLimit = 20000;
int[] truncatedForQuadratic = TruncateArray(largeArr, truncationLimit);
MeasureAndPrint("Bubble Sort (truncated to 20k)", BubbleSort, truncatedForQuadratic);
MeasureAndPrint("Insertion Sort (truncated to 20k)", InsertionSort, truncatedForQuadratic);

stopwatch.Stop();
Console.WriteLine("Total runtime (from program start):");
DisplayRuntime(stopwatch);

static void MeasureAndPrint(string name, Func<int[], int[]> sorter, int[] source)
{
    int[] inputCopy = CopyArray(source);
    Stopwatch sw = Stopwatch.StartNew();
    int[] sorted = sorter(inputCopy);
    sw.Stop();
    Console.WriteLine($"Algorithm: {name} Time Taken: {sw.ElapsedMilliseconds} ms");
}

// Bubble Sort
static int[] BubbleSort(int[] input)
{
    int[] arr = CopyArray(input);
    int n = arr.Length;
    bool swapped;
    for (int i = 0; i < n - 1; i++)
    {
        swapped = false;
        for (int j = 0; j < n - 1 - i; j++)
        {
            if (arr[j] > arr[j + 1])
            {
                int tmp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = tmp;
                swapped = true;
            }
        }
        if (!swapped) break;
    }
    return arr;
}

// Insertion Sort
static int[] InsertionSort(int[] input)
{
    int[] arr = CopyArray(input);
    int n = arr.Length;
    for (int i = 1; i < n; i++)
    {
        int key = arr[i];
        int j = i - 1;
        while (j >= 0 && arr[j] > key)
        {
            arr[j + 1] = arr[j];
            j--;
        }
        arr[j + 1] = key;
    }
    return arr;
}

// Merge Sort
static int[] MergeSort(int[] input)
{
    int[] arr = CopyArray(input);
    if (arr.Length <= 1) return arr;
    MergeSortInPlace(arr, 0, arr.Length - 1);
    return arr;
}

static void MergeSortInPlace(int[] arr, int left, int right)
{
    if (left >= right) return;
    int mid = left + (right - left) / 2;
    MergeSortInPlace(arr, left, mid);
    MergeSortInPlace(arr, mid + 1, right);
    Merge(arr, left, mid, right);
}

static void Merge(int[] arr, int left, int mid, int right)
{
    int n1 = mid - left + 1;
    int n2 = right - mid;
    int[] leftArr = new int[n1];
    int[] rightArr = new int[n2];

    for (int i = 0; i < n1; i++) leftArr[i] = arr[left + i];
    for (int j = 0; j < n2; j++) rightArr[j] = arr[mid + 1 + j];

    int ii = 0, jj = 0, k = left;
    while (ii < n1 && jj < n2)
    {
        if (leftArr[ii] <= rightArr[jj])
        {
            arr[k++] = leftArr[ii++];
        }
        else
        {
            arr[k++] = rightArr[jj++];
        }
    }
    while (ii < n1) arr[k++] = leftArr[ii++];
    while (jj < n2) arr[k++] = rightArr[jj++];
}

// Quick Sort
static int[] QuickSort(int[] input)
{
    int[] arr = CopyArray(input);
    QuickSortInPlace(arr, 0, arr.Length - 1);
    return arr;
}

static void QuickSortInPlace(int[] arr, int low, int high)
{
    if (low < high)
    {
        int p = Partition(arr, low, high);
        QuickSortInPlace(arr, low, p - 1);
        QuickSortInPlace(arr, p + 1, high);
    }
}

// Lomuto partition
static int Partition(int[] arr, int low, int high)
{
    int pivot = arr[high];
    int i = low - 1;
    for (int j = low; j <= high - 1; j++)
    {
        if (arr[j] <= pivot)
        {
            i++;
            int tmp = arr[i];
            arr[i] = arr[j];
            arr[j] = tmp;
        }
    }
    int tmp2 = arr[i + 1];
    arr[i + 1] = arr[high];
    arr[high] = tmp2;
    return i + 1;
}

static int[] GenerateRandomArray(int length, int minValue, int maxValue)
{
    Random rand = new Random();
    int[] array = new int[length];

    for (int i = 0; i < length; i++)
    {
        array[i] = rand.Next(minValue, maxValue);
    }

    return array;
}

static int[] CopyArray(int[] source)
{
    int[] copy = new int[source.Length];
    for (int i = 0; i < source.Length; i++) copy[i] = source[i];
    return copy;
}

static int[] TruncateArray(int[] source, int newLength)
{
    int len = Math.Min(newLength, source.Length);
    int[] result = new int[len];
    for (int i = 0; i < len; i++) result[i] = source[i];
    return result;
}

static void DisplayRuntime(Stopwatch stopwatch)
{
    TimeSpan ts = stopwatch.Elapsed;

    string elapsedTime = String.Format("{0:00}:{1:00}:{2:00}.{3:00}",
        ts.Hours, ts.Minutes, ts.Seconds,
        ts.Milliseconds / 10);
    Console.WriteLine("Time Taken: " + elapsedTime);
}

static bool IsSorted(int[] arr)
{
    for (int i = 1; i < arr.Length; i++)
    {
        if (arr[i - 1] > arr[i]) return false;
    }
    return true;
}